fx_version 'bodacious'
games {'gta5'}

data_file 'INTERIOR_PROXY_ORDER_FILE' 'interiorproxies.meta'

files {
    "interiorproxies.meta"
}