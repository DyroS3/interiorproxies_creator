# FiveM - Interior proxy creator

Interior proxy creator for FiveM.

## Installation

Use the following nodeJS commands or run install.cmd: 

```bash
cd src
npm install
```

## Usage

1. Upload all interiors to the input folder.
2. After that run start.cmd. Resource will be created in the /output/ folder.

## License
[GNU General Public License v3.0](https://www.gnu.org/licenses/gpl-3.0.html)
